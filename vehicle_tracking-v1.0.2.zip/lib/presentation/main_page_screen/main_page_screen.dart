import 'package:flutter/material.dart';
import 'package:vehicle_tracking/core/app_export.dart';
import 'package:vehicle_tracking/widgets/custom_elevated_button.dart';

class MainPageScreen extends StatelessWidget {
  const MainPageScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            children: [
              CustomElevatedButton(
                text: "Kgisl Institute of technology",
              ),
              Spacer(
                flex: 48,
              ),
              Padding(
                padding: EdgeInsets.only(
                  left: 29.h,
                  right: 33.h,
                ),
                child: _buildFrameSixteen(context),
              ),
              SizedBox(height: 83.v),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 31.h),
                child: _buildFrameSixteen(context),
              ),
              Spacer(
                flex: 51,
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Common widget
  Widget _buildFrameSixteen(BuildContext context) {
    return Container(
      decoration: AppDecoration.fillIndigo,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 368.h,
            padding: EdgeInsets.symmetric(
              horizontal: 30.h,
              vertical: 29.v,
            ),
            decoration: AppDecoration.fillBlue,
            child: Text(
              "STUDENT LOGIN",
              style: CustomTextStyles.headlineSmallBlack900,
            ),
          ),
          SizedBox(height: 24.v),
          CustomImageView(
            imagePath: ImageConstant.imgLayer1,
            height: 153.v,
            width: 144.h,
            margin: EdgeInsets.only(left: 105.h),
          ),
          SizedBox(height: 20.v),
        ],
      ),
    );
  }
}
