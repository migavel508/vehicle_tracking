import 'package:flutter/material.dart';
import 'package:vehicle_tracking/core/app_export.dart';

class Iphone1415ProMaxTenScreen extends StatelessWidget {
  const Iphone1415ProMaxTenScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          height: mediaQueryData.size.height,
          width: double.maxFinite,
        ),
      ),
    );
  }
}
