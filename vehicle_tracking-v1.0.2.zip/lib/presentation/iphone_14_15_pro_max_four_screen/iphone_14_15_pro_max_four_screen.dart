import 'package:flutter/material.dart';
import 'package:vehicle_tracking/core/app_export.dart';

class Iphone1415ProMaxFourScreen extends StatelessWidget {
  const Iphone1415ProMaxFourScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: SizedBox(
                width: double.maxFinite,
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                          width: double.maxFinite,
                          padding: EdgeInsets.symmetric(
                              horizontal: 30.h, vertical: 1.v),
                          decoration: AppDecoration.fillBlue50002,
                          child: Text("KGiSL Transport ",
                              style: theme.textTheme.headlineSmall)),
                      SizedBox(height: 8.v),
                      Padding(
                          padding: EdgeInsets.only(right: 44.h),
                          child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CustomImageView(
                                    imagePath: ImageConstant.imgClose,
                                    height: 25.v,
                                    width: 47.h,
                                    margin: EdgeInsets.only(bottom: 334.v),
                                    onTap: () {
                                      onTapImgClose(context);
                                    }),
                                Container(
                                    margin: EdgeInsets.only(top: 13.v),
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 21.h, vertical: 46.v),
                                    decoration: AppDecoration.fillOnPrimary
                                        .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder20),
                                    child: Container(
                                        width: 292.h,
                                        margin: EdgeInsets.only(left: 4.h),
                                        child: Text(
                                            "Hurry up !....\n\nYour bus was ready\nIt will leave from campus\nsoon ......",
                                            maxLines: 5,
                                            overflow: TextOverflow.ellipsis,
                                            style:
                                                theme.textTheme.headlineSmall)))
                              ])),
                      SizedBox(height: 5.v)
                    ]))));
  }

  /// Navigates back to the previous screen.
  onTapImgClose(BuildContext context) {
    Navigator.pop(context);
  }
}
