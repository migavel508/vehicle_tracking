import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;
import 'package:vehicle_tracking/core/app_export.dart';
import 'package:vehicle_tracking/widgets/custom_elevated_button.dart';

class RemainingViewScreen extends StatelessWidget {
  const RemainingViewScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: SizedBox(
                width: double.maxFinite,
                child: Column(children: [
                  CustomElevatedButton(text: "Kgisl Institute of technology"),
                  SizedBox(height: 18.v),
                  Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                          height: 25.v,
                          width: 47.h,
                          margin: EdgeInsets.only(left: 11.h),
                          child: Stack(alignment: Alignment.center, children: [
                            CustomImageView(
                                imagePath: ImageConstant.imgClose,
                                height: 25.v,
                                width: 47.h,
                                alignment: Alignment.center,
                                onTap: () {
                                  onTapImgClose(context);
                                }),
                            CustomImageView(
                                imagePath: ImageConstant.imgClose,
                                height: 25.v,
                                width: 47.h,
                                alignment: Alignment.center)
                          ]))),
                  Container(
                      width: 338.h,
                      margin: EdgeInsets.symmetric(horizontal: 46.h),
                      padding:
                          EdgeInsets.symmetric(horizontal: 7.h, vertical: 3.v),
                      decoration: AppDecoration.outlineBlack.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder20),
                      child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            SizedBox(height: 5.v),
                            Container(
                                width: 306.h,
                                margin: EdgeInsets.only(left: 18.h),
                                child: Text("Bus No:1\nKGiSL - Gandhipuram",
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.center,
                                    style: theme.textTheme.headlineLarge))
                          ])),
                  SizedBox(height: 51.v),
                  Padding(
                      padding: EdgeInsets.only(left: 25.h, right: 18.h),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Padding(
                                padding:
                                    EdgeInsets.only(top: 127.v, bottom: 33.v),
                                child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      CustomImageView(
                                          imagePath: ImageConstant.imgUser,
                                          height: 48.v,
                                          width: 41.h),
                                      SizedBox(height: 8.v),
                                      Align(
                                          alignment: Alignment.centerRight,
                                          child: Container(
                                              height: 34.v,
                                              width: 78.h,
                                              margin:
                                                  EdgeInsets.only(right: 3.h),
                                              child: Stack(
                                                  alignment:
                                                      Alignment.bottomLeft,
                                                  children: [
                                                    CustomImageView(
                                                        imagePath: ImageConstant
                                                            .imgArrow3,
                                                        height: 31.v,
                                                        width: 78.h,
                                                        alignment: Alignment
                                                            .topCenter),
                                                    Align(
                                                        alignment: Alignment
                                                            .bottomLeft,
                                                        child: Container(
                                                            width: 35.h,
                                                            margin:
                                                                EdgeInsets.only(
                                                                    left: 14.h),
                                                            child: Text(
                                                                "5meters",
                                                                maxLines: 2,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                style: theme
                                                                    .textTheme
                                                                    .bodySmall)))
                                                  ]))),
                                      SizedBox(height: 82.v),
                                      Align(
                                          alignment: Alignment.centerRight,
                                          child: Container(
                                              width: 84.h,
                                              margin:
                                                  EdgeInsets.only(left: 48.h),
                                              padding: EdgeInsets.symmetric(
                                                  horizontal: 15.h,
                                                  vertical: 56.v),
                                              decoration: BoxDecoration(
                                                  image: DecorationImage(
                                                      image: fs.Svg(
                                                          ImageConstant
                                                              .imgGroup5),
                                                      fit: BoxFit.cover)),
                                              child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    SizedBox(height: 6.v),
                                                    SizedBox(
                                                        width: 26.h,
                                                        child: Text("25 meters",
                                                            maxLines: 4,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            style: theme
                                                                .textTheme
                                                                .bodySmall))
                                                  ]))),
                                      SizedBox(height: 15.v),
                                      CustomImageView(
                                          imagePath: ImageConstant.imgUser,
                                          height: 48.v,
                                          width: 41.h,
                                          margin: EdgeInsets.only(left: 20.h))
                                    ])),
                            Padding(
                                padding:
                                    EdgeInsets.only(left: 2.h, bottom: 155.v),
                                child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      CustomImageView(
                                          imagePath: ImageConstant.imgUser,
                                          height: 48.v,
                                          width: 41.h),
                                      SizedBox(height: 17.v),
                                      Container(
                                          height: 149.v,
                                          width: 33.h,
                                          margin: EdgeInsets.only(left: 17.h),
                                          child: Stack(
                                              alignment: Alignment.centerLeft,
                                              children: [
                                                CustomImageView(
                                                    imagePath:
                                                        ImageConstant.imgArrow7,
                                                    height: 149.v,
                                                    width: 30.h,
                                                    alignment:
                                                        Alignment.centerRight),
                                                Align(
                                                    alignment:
                                                        Alignment.centerLeft,
                                                    child: SizedBox(
                                                        width: 16.h,
                                                        child: Text("15 meters",
                                                            maxLines: 4,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            style: theme
                                                                .textTheme
                                                                .bodySmall)))
                                              ])),
                                      Container(
                                          height: 139.v,
                                          width: 110.h,
                                          margin: EdgeInsets.only(left: 4.h),
                                          child: Stack(
                                              alignment: Alignment.bottomRight,
                                              children: [
                                                CustomImageView(
                                                    imagePath: ImageConstant
                                                        .imgBusYellow50001,
                                                    height: 90.v,
                                                    width: 110.h,
                                                    alignment:
                                                        Alignment.topCenter),
                                                CustomImageView(
                                                    imagePath:
                                                        ImageConstant.imgArrow5,
                                                    height: 48.v,
                                                    width: 12.h,
                                                    alignment:
                                                        Alignment.bottomRight,
                                                    margin: EdgeInsets.only(
                                                        right: 35.h,
                                                        bottom: 5.v)),
                                                Align(
                                                    alignment:
                                                        Alignment.bottomRight,
                                                    child: Container(
                                                        width: 18.h,
                                                        margin: EdgeInsets.only(
                                                            right: 19.h),
                                                        child: Text("3 meters",
                                                            maxLines: 4,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            style: theme
                                                                .textTheme
                                                                .bodySmall)))
                                              ])),
                                      SizedBox(height: 3.v),
                                      CustomImageView(
                                          imagePath: ImageConstant.imgUser,
                                          height: 48.v,
                                          width: 41.h,
                                          alignment: Alignment.centerRight,
                                          margin: EdgeInsets.only(right: 14.h))
                                    ])),
                            Padding(
                                padding: EdgeInsets.only(left: 6.h, top: 41.v),
                                child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      CustomImageView(
                                          imagePath: ImageConstant.imgUser,
                                          height: 48.v,
                                          width: 41.h,
                                          alignment: Alignment.centerRight,
                                          margin: EdgeInsets.only(right: 35.h)),
                                      SizedBox(height: 24.v),
                                      Container(
                                          width: 61.h,
                                          margin: EdgeInsets.only(right: 69.h),
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 8.h, vertical: 21.v),
                                          decoration: BoxDecoration(
                                              image: DecorationImage(
                                                  image: fs.Svg(
                                                      ImageConstant.imgGroup6),
                                                  fit: BoxFit.cover)),
                                          child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.end,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.end,
                                              children: [
                                                SizedBox(height: 22.v),
                                                SizedBox(
                                                    width: 27.h,
                                                    child: Text("10 meters",
                                                        maxLines: 4,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        style: theme.textTheme
                                                            .bodySmall))
                                              ])),
                                      SizedBox(height: 75.v),
                                      Container(
                                          width: 96.h,
                                          margin: EdgeInsets.only(
                                              left: 13.h, right: 21.h),
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 19.h, vertical: 77.v),
                                          decoration: BoxDecoration(
                                              image: DecorationImage(
                                                  image: fs.Svg(
                                                      ImageConstant.imgGroup4),
                                                  fit: BoxFit.cover)),
                                          child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.end,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                SizedBox(height: 6.v),
                                                Text("30 meters",
                                                    style: theme
                                                        .textTheme.bodySmall)
                                              ])),
                                      SizedBox(height: 8.v),
                                      CustomImageView(
                                          imagePath: ImageConstant.imgUser,
                                          height: 48.v,
                                          width: 41.h,
                                          alignment: Alignment.centerRight)
                                    ]))
                          ])),
                  SizedBox(height: 5.v)
                ]))));
  }

  /// Navigates back to the previous screen.
  onTapImgClose(BuildContext context) {
    Navigator.pop(context);
  }
}
