import 'package:flutter/material.dart';
import 'package:vehicle_tracking/core/app_export.dart';
import 'package:vehicle_tracking/widgets/custom_elevated_button.dart';

class BusDriverPageScreen extends StatelessWidget {
  const BusDriverPageScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: SizedBox(
                width: double.maxFinite,
                child: Column(children: [
                  CustomElevatedButton(text: "Kgisl Institute of technology"),
                  _buildFrameTen(context),
                  SizedBox(height: 74.v),
                  Container(
                      width: 338.h,
                      margin: EdgeInsets.only(left: 49.h, right: 43.h),
                      padding:
                          EdgeInsets.symmetric(horizontal: 7.h, vertical: 3.v),
                      decoration: AppDecoration.outlineBlack.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder20),
                      child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            SizedBox(height: 5.v),
                            Container(
                                width: 306.h,
                                margin: EdgeInsets.only(left: 18.h),
                                child: Text("Bus No:1\nKGiSL - Gandhipuram",
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.center,
                                    style: theme.textTheme.headlineLarge))
                          ])),
                  Spacer(),
                  Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                          padding: EdgeInsets.only(left: 49.h),
                          child: Text("TOTAL  STUDENTS: 50",
                              style: CustomTextStyles
                                  .headlineSmallBlack900SemiBold))),
                  SizedBox(height: 49.v),
                  _buildFrameTwo(context),
                  SizedBox(height: 22.v)
                ]))));
  }

  /// Section Widget
  Widget _buildFrameTen(BuildContext context) {
    return Container(
        width: 429.h,
        padding: EdgeInsets.symmetric(horizontal: 16.h),
        decoration: AppDecoration.fillBlue50,
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 1.v),
              Container(
                  width: 59.adaptSize,
                  padding:
                      EdgeInsets.symmetric(horizontal: 18.h, vertical: 13.v),
                  decoration: AppDecoration.fillBlue300.copyWith(
                      borderRadius: BorderRadiusStyle.roundedBorder29),
                  child: Text("M",
                      style: CustomTextStyles.headlineSmallBlack900_1))
            ]));
  }

  /// Section Widget
  Widget _buildFrameTwo(BuildContext context) {
    return Container(
        margin: EdgeInsets.only(left: 40.h, right: 24.h),
        padding: EdgeInsets.symmetric(horizontal: 16.h, vertical: 35.v),
        decoration: AppDecoration.fillOnPrimaryContainer,
        child: Column(children: [
          CustomElevatedButton(
              height: 63.v,
              text: "PRESENT : 43",
              buttonStyle: CustomButtonStyles.fillBlueGray,
              buttonTextStyle: CustomTextStyles.headlineSmallBlack900SemiBold),
          SizedBox(height: 18.v),
          CustomElevatedButton(
              height: 59.v,
              text: "REMAINING : 7",
              buttonStyle: CustomButtonStyles.fillBlueGray,
              buttonTextStyle: CustomTextStyles.headlineSmallBlack900SemiBold),
          SizedBox(height: 43.v),
          Padding(
              padding: EdgeInsets.only(left: 4.h),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                        height: 136.v,
                        width: 143.h,
                        margin: EdgeInsets.only(bottom: 2.v),
                        child: Stack(alignment: Alignment.center, children: [
                          Align(
                              alignment: Alignment.center,
                              child: GestureDetector(
                                  onTap: () {
                                    onTapView(context);
                                  },
                                  child: Container(
                                      height: 136.v,
                                      width: 143.h,
                                      decoration: BoxDecoration(
                                          color: appTheme.yellow500,
                                          borderRadius:
                                              BorderRadius.circular(71.h))))),
                          Align(
                              alignment: Alignment.center,
                              child: Text("VIEW",
                                  style:
                                      CustomTextStyles.headlineSmallBlack900))
                        ])),
                    SizedBox(
                        height: 138.v,
                        width: 152.h,
                        child: Stack(alignment: Alignment.center, children: [
                          Align(
                              alignment: Alignment.center,
                              child: GestureDetector(
                                  onTap: () {
                                    onTapView1(context);
                                  },
                                  child: Container(
                                      height: 138.v,
                                      width: 152.h,
                                      decoration: BoxDecoration(
                                          color: appTheme.red500,
                                          borderRadius:
                                              BorderRadius.circular(76.h))))),
                          Align(
                              alignment: Alignment.center,
                              child: Text("ALERT",
                                  style:
                                      CustomTextStyles.headlineSmallBlack900))
                        ]))
                  ])),
          SizedBox(height: 9.v)
        ]));
  }

  /// Navigates to the remainingViewScreen when the action is triggered.
  onTapView(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.remainingViewScreen);
  }

  /// Navigates to the iphone1415ProMaxFourScreen when the action is triggered.
  onTapView1(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.iphone1415ProMaxFourScreen);
  }
}
