import 'package:flutter/material.dart';
import 'package:vehicle_tracking/core/app_export.dart';
import 'package:vehicle_tracking/widgets/custom_text_form_field.dart';

// ignore_for_file: must_be_immutable
class BusDetScreen extends StatelessWidget {
  BusDetScreen({Key? key}) : super(key: key);

  TextEditingController searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: SizedBox(
                width: double.maxFinite,
                child: Column(children: [
                  Container(
                      width: double.maxFinite,
                      padding:
                          EdgeInsets.symmetric(horizontal: 30.h, vertical: 9.v),
                      decoration: AppDecoration.fillBlue50001,
                      child: Text("KGiSL Transport ",
                          style: theme.textTheme.headlineSmall)),
                  SizedBox(height: 15.v),
                  _buildThirtyThree(context),
                  SizedBox(height: 44.v),
                  SizedBox(
                      height: 695.v,
                      width: 338.h,
                      child:
                          Stack(alignment: Alignment.bottomCenter, children: [
                        Align(
                            alignment: Alignment.topCenter,
                            child: Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 7.h, vertical: 3.v),
                                decoration: AppDecoration.outlineBlack.copyWith(
                                    borderRadius:
                                        BorderRadiusStyle.roundedBorder20),
                                child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      SizedBox(height: 5.v),
                                      Container(
                                          width: 306.h,
                                          margin: EdgeInsets.only(left: 18.h),
                                          child: Text(
                                              "Bus No:1\nKGiSL - Gandhipuram",
                                              maxLines: 2,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.center,
                                              style: theme
                                                  .textTheme.headlineLarge))
                                    ]))),
                        Align(
                            alignment: Alignment.bottomCenter,
                            child: SizedBox(
                                height: 387.v,
                                child: VerticalDivider(
                                    width: 2.h,
                                    thickness: 2.v,
                                    endIndent: 159.h))),
                        Align(
                            alignment: Alignment.bottomRight,
                            child: Padding(
                                padding: EdgeInsets.only(
                                    right: 128.h, bottom: 186.v),
                                child: Text("10 meters",
                                    style: theme.textTheme.headlineLarge))),
                        CustomImageView(
                            imagePath: ImageConstant.imgPerson,
                            height: 169.v,
                            width: 208.h,
                            alignment: Alignment.bottomCenter),
                        CustomImageView(
                            imagePath: ImageConstant.imgBus,
                            height: 241.v,
                            width: 213.h,
                            alignment: Alignment.topRight,
                            margin: EdgeInsets.only(top: 82.v, right: 54.h))
                      ])),
                  SizedBox(height: 5.v)
                ]))));
  }

  /// Section Widget
  Widget _buildThirtyThree(BuildContext context) {
    return Align(
        alignment: Alignment.centerLeft,
        child: Padding(
            padding: EdgeInsets.only(left: 5.h, right: 22.h),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              CustomImageView(
                  imagePath: ImageConstant.imgClose,
                  height: 19.v,
                  width: 34.h,
                  margin: EdgeInsets.only(top: 6.v, bottom: 21.v),
                  onTap: () {
                    onTapImgClose(context);
                  }),
              Expanded(
                  child: Padding(
                      padding: EdgeInsets.only(left: 7.h),
                      child: CustomTextFormField(
                          controller: searchController,
                          hintText: "KGiSL - Gandhipuram",
                          textInputAction: TextInputAction.done,
                          prefix: Container(
                              margin: EdgeInsets.fromLTRB(7.h, 5.v, 6.h, 9.v),
                              child: CustomImageView(
                                  imagePath: ImageConstant.imgSearch,
                                  height: 32.v,
                                  width: 24.h)),
                          prefixConstraints: BoxConstraints(maxHeight: 46.v),
                          suffix: Container(
                              margin: EdgeInsets.fromLTRB(22.h, 1.v, 6.h, 1.v),
                              child: CustomImageView(
                                  imagePath: ImageConstant.imgSearch,
                                  height: 44.v,
                                  width: 42.h)),
                          suffixConstraints: BoxConstraints(maxHeight: 46.v))))
            ])));
  }

  /// Navigates back to the previous screen.
  onTapImgClose(BuildContext context) {
    Navigator.pop(context);
  }
}
