import '../iphone_14_15_pro_max_nine_screen/widgets/framefourteen_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:vehicle_tracking/core/app_export.dart';

class Iphone1415ProMaxNineScreen extends StatelessWidget {
  const Iphone1415ProMaxNineScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: SizedBox(
                width: double.maxFinite,
                child: Column(children: [
                  Container(
                      width: double.maxFinite,
                      padding:
                          EdgeInsets.symmetric(horizontal: 30.h, vertical: 9.v),
                      decoration: AppDecoration.fillBlue50002,
                      child: Text("KGiSL Transport ",
                          style: theme.textTheme.headlineSmall)),
                  SizedBox(height: 16.v),
                  _buildFrameEleven(context),
                  SizedBox(height: 28.v),
                  _buildFrameFourteen(context)
                ]))));
  }

  /// Section Widget
  Widget _buildFrameEleven(BuildContext context) {
    return Container(
        margin: EdgeInsets.symmetric(horizontal: 34.h),
        padding: EdgeInsets.symmetric(horizontal: 6.h, vertical: 1.v),
        decoration: AppDecoration.fillBluegray10002
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder10),
        child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              CustomImageView(
                  imagePath: ImageConstant.imgSearch,
                  height: 32.v,
                  width: 24.h,
                  margin: EdgeInsets.only(left: 1.h, top: 4.v, bottom: 8.v)),
              Padding(
                  padding: EdgeInsets.only(left: 7.h, top: 6.v, bottom: 6.v),
                  child: Text("KGiSL - Sathy",
                      style: CustomTextStyles.headlineSmallBlack900_1)),
              Spacer(),
              CustomImageView(
                  imagePath: ImageConstant.imgSearch, height: 44.v, width: 42.h)
            ]));
  }

  /// Section Widget
  Widget _buildFrameFourteen(BuildContext context) {
    return Expanded(
        child: Container(
            margin: EdgeInsets.symmetric(horizontal: 34.h),
            padding: EdgeInsets.symmetric(horizontal: 12.h, vertical: 26.v),
            decoration: AppDecoration.fillBluegray10003
                .copyWith(borderRadius: BorderRadiusStyle.roundedBorder10),
            child: ListView.separated(
                physics: BouncingScrollPhysics(),
                shrinkWrap: true,
                separatorBuilder: (context, index) {
                  return SizedBox(height: 35.v);
                },
                itemCount: 3,
                itemBuilder: (context, index) {
                  return FramefourteenItemWidget(onTapFrame: () {
                    onTapFrame(context);
                  });
                })));
  }

  /// Navigates to the iphone1415ProMaxEightScreen when the action is triggered.
  onTapFrame(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.iphone1415ProMaxEightScreen);
  }
}
