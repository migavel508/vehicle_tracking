import 'package:flutter/material.dart';
import 'package:vehicle_tracking/core/app_export.dart';

class Iphone1415ProMaxSevenScreen extends StatelessWidget {
  const Iphone1415ProMaxSevenScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            children: [
              Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(
                  horizontal: 30.h,
                  vertical: 9.v,
                ),
                decoration: AppDecoration.fillBlue50001,
                child: Text(
                  "KGiSL Transport ",
                  style: theme.textTheme.headlineSmall,
                ),
              ),
              SizedBox(height: 11.v),
              _buildFrameEleven(context),
              SizedBox(height: 26.v),
              SizedBox(
                height: 91.v,
                width: 338.h,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Align(
                      alignment: Alignment.bottomLeft,
                      child: Padding(
                        padding: EdgeInsets.only(
                          left: 18.h,
                          bottom: 9.v,
                        ),
                        child: Text(
                          "KGiSL Transport ",
                          style: theme.textTheme.headlineSmall,
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.center,
                      child: Container(
                        padding: EdgeInsets.symmetric(
                          horizontal: 60.h,
                          vertical: 3.v,
                        ),
                        decoration: AppDecoration.outlineBlack.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder20,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            SizedBox(height: 5.v),
                            SizedBox(
                              width: 197.h,
                              child: Text(
                                "Bus No:5\nKGiSL - Sathy",
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.center,
                                style: theme.textTheme.headlineLarge,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 3.v),
              CustomImageView(
                imagePath: ImageConstant.imgBus,
                height: 241.v,
                width: 213.h,
              ),
              SizedBox(height: 20.v),
              Align(
                alignment: Alignment.centerRight,
                child: Padding(
                  padding: EdgeInsets.only(right: 176.h),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      SizedBox(
                        height: 102.v,
                        child: VerticalDivider(
                          width: 1.h,
                          thickness: 1.v,
                          color: appTheme.black900,
                          endIndent: 2.h,
                        ),
                      ),
                      Container(
                        width: 18.h,
                        margin: EdgeInsets.only(
                          left: 11.h,
                          top: 11.v,
                        ),
                        child: Text(
                          "2 meters",
                          maxLines: 4,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                          style: theme.textTheme.titleLarge,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 53.v),
              CustomImageView(
                imagePath: ImageConstant.imgPerson,
                height: 169.v,
                width: 208.h,
              ),
              SizedBox(height: 5.v),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildFrameEleven(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 34.h),
      padding: EdgeInsets.symmetric(
        horizontal: 6.h,
        vertical: 1.v,
      ),
      decoration: AppDecoration.fillBluegray10002.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder10,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgSearch,
            height: 32.v,
            width: 24.h,
            margin: EdgeInsets.only(
              left: 1.h,
              top: 4.v,
              bottom: 8.v,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 6.h,
              top: 6.v,
              bottom: 6.v,
            ),
            child: Text(
              "KGiSL - Sathy",
              style: CustomTextStyles.headlineSmallBlack900_1,
            ),
          ),
          Spacer(),
          CustomImageView(
            imagePath: ImageConstant.imgSearch,
            height: 44.v,
            width: 42.h,
          ),
        ],
      ),
    );
  }
}
