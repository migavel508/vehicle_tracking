import 'package:flutter/material.dart';
import 'package:vehicle_tracking/core/app_export.dart';

class Iphone1415ProMaxEightScreen extends StatelessWidget {
  const Iphone1415ProMaxEightScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            children: [
              Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(
                  horizontal: 30.h,
                  vertical: 9.v,
                ),
                decoration: AppDecoration.fillBlue500,
                child: Text(
                  "KGiSL Transport ",
                  style: theme.textTheme.headlineSmall,
                ),
              ),
              SizedBox(height: 13.v),
              _buildFrameEleven(context),
              SizedBox(height: 12.v),
              SizedBox(
                height: 315.v,
                width: 338.h,
                child: Stack(
                  alignment: Alignment.bottomCenter,
                  children: [
                    Align(
                      alignment: Alignment.topLeft,
                      child: Padding(
                        padding: EdgeInsets.only(
                          left: 27.h,
                          top: 62.v,
                        ),
                        child: Text(
                          "KGiSL Transport ",
                          style: theme.textTheme.headlineSmall,
                        ),
                      ),
                    ),
                    CustomImageView(
                      imagePath: ImageConstant.imgBus,
                      height: 241.v,
                      width: 213.h,
                      alignment: Alignment.bottomCenter,
                    ),
                    Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                        padding: EdgeInsets.symmetric(
                          horizontal: 59.h,
                          vertical: 3.v,
                        ),
                        decoration: AppDecoration.outlineBlack.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder20,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(height: 4.v),
                            SizedBox(
                              width: 197.h,
                              child: Text(
                                "Bus No:9\nKGiSL - Sathy",
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.center,
                                style: theme.textTheme.headlineLarge,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 11.v),
              Align(
                alignment: Alignment.centerRight,
                child: Padding(
                  padding: EdgeInsets.only(right: 176.h),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      SizedBox(
                        height: 186.v,
                        child: VerticalDivider(
                          width: 3.h,
                          thickness: 3.v,
                          color: appTheme.black900,
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                          left: 12.h,
                          top: 24.v,
                          bottom: 25.v,
                        ),
                        child: Text(
                          "5 meters",
                          style: theme.textTheme.headlineLarge,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 23.v),
              CustomImageView(
                imagePath: ImageConstant.imgPerson,
                height: 169.v,
                width: 208.h,
              ),
              SizedBox(height: 5.v),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildFrameEleven(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(
        left: 30.h,
        right: 38.h,
      ),
      padding: EdgeInsets.symmetric(
        horizontal: 6.h,
        vertical: 1.v,
      ),
      decoration: AppDecoration.fillBluegray10002.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder10,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgSearch,
            height: 32.v,
            width: 24.h,
            margin: EdgeInsets.only(
              left: 1.h,
              top: 4.v,
              bottom: 8.v,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 6.h,
              top: 6.v,
              bottom: 6.v,
            ),
            child: Text(
              "KGiSL - Sathy",
              style: CustomTextStyles.headlineSmallBlack900_1,
            ),
          ),
          Spacer(),
          CustomImageView(
            imagePath: ImageConstant.imgSearch,
            height: 44.v,
            width: 42.h,
          ),
        ],
      ),
    );
  }
}
