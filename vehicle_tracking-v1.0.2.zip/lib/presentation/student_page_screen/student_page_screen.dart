import '../student_page_screen/widgets/studentpage_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:vehicle_tracking/core/app_export.dart';
import 'package:vehicle_tracking/widgets/custom_search_view.dart';

// ignore_for_file: must_be_immutable
class StudentPageScreen extends StatelessWidget {
  StudentPageScreen({Key? key}) : super(key: key);

  TextEditingController searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: SizedBox(
                width: double.maxFinite,
                child: Column(children: [
                  Container(
                      width: double.maxFinite,
                      padding:
                          EdgeInsets.symmetric(horizontal: 30.h, vertical: 9.v),
                      decoration: AppDecoration.fillBlue50002,
                      child: Text("KGiSL Transport ",
                          style: theme.textTheme.headlineSmall)),
                  SizedBox(height: 12.v),
                  Padding(
                      padding: EdgeInsets.only(left: 29.h, right: 39.h),
                      child: CustomSearchView(
                          controller: searchController, hintText: "Search")),
                  SizedBox(height: 21.v),
                  Container(
                      margin: EdgeInsets.only(left: 34.h, right: 39.h),
                      padding:
                          EdgeInsets.symmetric(horizontal: 9.h, vertical: 18.v),
                      decoration: AppDecoration.fillBlueGray.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder10),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        _buildStudentpage(context),
                        SizedBox(height: 18.v),
                        Container(
                            width: 338.h,
                            margin: EdgeInsets.only(left: 1.h),
                            padding: EdgeInsets.symmetric(
                                horizontal: 40.h, vertical: 3.v),
                            decoration: AppDecoration.outlineBlack.copyWith(
                                borderRadius:
                                    BorderRadiusStyle.roundedBorder20),
                            child: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.end,
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  SizedBox(height: 5.v),
                                  Container(
                                      width: 235.h,
                                      margin: EdgeInsets.only(left: 21.h),
                                      child: Text("Bus No:5\nKGiSL - Thirupur",
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.center,
                                          style: theme.textTheme.headlineLarge))
                                ])),
                        SizedBox(height: 30.v),
                        Container(
                            width: 338.h,
                            margin: EdgeInsets.only(left: 1.h),
                            padding: EdgeInsets.symmetric(
                                horizontal: 31.h, vertical: 3.v),
                            decoration: AppDecoration.outlineBlack.copyWith(
                                borderRadius:
                                    BorderRadiusStyle.roundedBorder20),
                            child: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.end,
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  SizedBox(height: 5.v),
                                  Container(
                                      width: 255.h,
                                      margin: EdgeInsets.only(left: 18.h),
                                      child: Text("Bus No:6\nKGiSL - Sirumugai",
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.center,
                                          style: theme.textTheme.headlineLarge))
                                ])),
                        SizedBox(height: 38.v)
                      ])),
                  SizedBox(height: 5.v)
                ]))));
  }

  /// Section Widget
  Widget _buildStudentpage(BuildContext context) {
    return Padding(
        padding: EdgeInsets.only(left: 1.h),
        child: ListView.separated(
            physics: NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            separatorBuilder: (context, index) {
              return SizedBox(height: 30.v);
            },
            itemCount: 4,
            itemBuilder: (context, index) {
              return StudentpageItemWidget(onTapFrame: () {
                onTapFrame(context);
              });
            }));
  }

  /// Navigates to the iphone1415ProMaxNineScreen when the action is triggered.
  onTapFrame(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.iphone1415ProMaxNineScreen);
  }
}
