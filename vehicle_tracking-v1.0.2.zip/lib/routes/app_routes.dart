import 'package:flutter/material.dart';
import 'package:vehicle_tracking/presentation/main_page_screen/main_page_screen.dart';
import 'package:vehicle_tracking/presentation/student_page_screen/student_page_screen.dart';
import 'package:vehicle_tracking/presentation/iphone_14_15_pro_max_nine_screen/iphone_14_15_pro_max_nine_screen.dart';
import 'package:vehicle_tracking/presentation/bus_det_screen/bus_det_screen.dart';
import 'package:vehicle_tracking/presentation/iphone_14_15_pro_max_seven_screen/iphone_14_15_pro_max_seven_screen.dart';
import 'package:vehicle_tracking/presentation/iphone_14_15_pro_max_four_screen/iphone_14_15_pro_max_four_screen.dart';
import 'package:vehicle_tracking/presentation/iphone_14_15_pro_max_eight_screen/iphone_14_15_pro_max_eight_screen.dart';
import 'package:vehicle_tracking/presentation/bus_driver_page_screen/bus_driver_page_screen.dart';
import 'package:vehicle_tracking/presentation/remaining_view_screen/remaining_view_screen.dart';
import 'package:vehicle_tracking/presentation/iphone_14_15_pro_max_ten_screen/iphone_14_15_pro_max_ten_screen.dart';
import 'package:vehicle_tracking/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String mainPageScreen = '/main_page_screen';

  static const String studentPageScreen = '/student_page_screen';

  static const String iphone1415ProMaxNineScreen =
      '/iphone_14_15_pro_max_nine_screen';

  static const String busDetScreen = '/bus_det_screen';

  static const String iphone1415ProMaxSevenScreen =
      '/iphone_14_15_pro_max_seven_screen';

  static const String iphone1415ProMaxFourScreen =
      '/iphone_14_15_pro_max_four_screen';

  static const String iphone1415ProMaxEightScreen =
      '/iphone_14_15_pro_max_eight_screen';

  static const String busDriverPageScreen = '/bus_driver_page_screen';

  static const String remainingViewScreen = '/remaining_view_screen';

  static const String iphone1415ProMaxTenScreen =
      '/iphone_14_15_pro_max_ten_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static Map<String, WidgetBuilder> routes = {
    mainPageScreen: (context) => MainPageScreen(),
    studentPageScreen: (context) => StudentPageScreen(),
    iphone1415ProMaxNineScreen: (context) => Iphone1415ProMaxNineScreen(),
    busDetScreen: (context) => BusDetScreen(),
    iphone1415ProMaxSevenScreen: (context) => Iphone1415ProMaxSevenScreen(),
    iphone1415ProMaxFourScreen: (context) => Iphone1415ProMaxFourScreen(),
    iphone1415ProMaxEightScreen: (context) => Iphone1415ProMaxEightScreen(),
    busDriverPageScreen: (context) => BusDriverPageScreen(),
    remainingViewScreen: (context) => RemainingViewScreen(),
    iphone1415ProMaxTenScreen: (context) => Iphone1415ProMaxTenScreen(),
    appNavigationScreen: (context) => AppNavigationScreen()
  };
}
