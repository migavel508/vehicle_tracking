class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Main page images
  static String imgLayer1 = '$imagePath/img_layer_1.svg';

  // remaining view  images
  static String imgUser = '$imagePath/img_user.svg';

  static String imgArrow3 = '$imagePath/img_arrow_3.svg';

  static String imgGroup5 = '$imagePath/img_group_5.svg';

  static String imgArrow7 = '$imagePath/img_arrow_7.svg';

  static String imgBusYellow50001 = '$imagePath/img_bus_yellow_500_01.svg';

  static String imgArrow5 = '$imagePath/img_arrow_5.svg';

  static String imgGroup6 = '$imagePath/img_group_6.svg';

  static String imgGroup4 = '$imagePath/img_group_4.svg';

  // Common images
  static String imgSearch = '$imagePath/img_search.png';

  static String imgClose = '$imagePath/img_close.svg';

  static String imgPerson = '$imagePath/img_person.png';

  static String imgBus = '$imagePath/img_bus.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
